﻿Public Class Form1
    '********************
    ' Calculator App    *|
    ' Computer Science  *|
    ' Rohan Nair        *|
    ' Project 3         *|
    ' Sept/Oct 2020     *|
    '********************


    ' Variables
    Dim num1 As Decimal ' First Number for calc
    Dim num2 As Decimal ' Second Number for calc
    Dim answer As Decimal ' Variable to store answer
    Dim AnswerDisplayed As Boolean = False ' Is the answer displayed on the screen
    Dim Newline = System.Environment.NewLine ' Creates new line in text box AKA Display for claculator
    Dim Mem As Decimal = 0 ' Variable for memory

    ''\ The  
    ''\ Number
    ''\ Buttons

#Region "Number"



    Private Sub Button0_Click(sender As Object, e As EventArgs) Handles Button0.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "0"
            AnswerDisplayed = False

        Else
            Display.Text = Display.Text & "0"
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "1"
            AnswerDisplayed = False

        Else
            Display.Text = Display.Text & "1"
        End If


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "2"
            AnswerDisplayed = False

        Else
            Display.Text = Display.Text & "2"
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "3"
            AnswerDisplayed = False

        Else
            Display.Text = Display.Text & "3"
        End If

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "4"
            AnswerDisplayed = False

        Else
            Display.Text = Display.Text & "4"
        End If

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "5"
            AnswerDisplayed = False

        Else
            Display.Text = Display.Text & "5"
        End If

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "6"
            AnswerDisplayed = False
        Else
            Display.Text = Display.Text & "6"
        End If

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = ""
            Display.Text = Display.Text & "7"
            AnswerDisplayed = False
        Else
            Display.Text = Display.Text & "7"
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        If AnswerDisplayed = True Then ' I think you get the point
            Display.Text = ""
            Display.Text = Display.Text & "8"
            AnswerDisplayed = False
        Else
            Display.Text = Display.Text & "8"
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If AnswerDisplayed = True Then
            Display.Text = ""
            Display.Text = Display.Text & "9"
            AnswerDisplayed = False
        Else
            Display.Text = Display.Text & "9"
        End If
    End Sub

    ' Button that adds a decimal
    Private Sub ButtonDecimal_Click(sender As Object, e As EventArgs) Handles ButtonDecimal.Click
        Display.Text = Display.Text & "."
        ButtonDecimal.Enabled = False
    End Sub

    ' Button to clear
    Private Sub ButtonClear_Click(sender As Object, e As EventArgs) Handles ButtonClear.Click
        Display.Text = ""
        EnableOpps() 'Enable all operations
        ButtonDecimal.Enabled = True ' Enable Decimal

    End Sub

    Private Sub ButtonPi_Click(sender As Object, e As EventArgs) Handles ButtonPi.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = Str(Math.PI)
            AnswerDisplayed = False
        Else
            Display.Text = Display.Text & Str(Math.PI)
        End If
    End Sub
#End Region

    Sub DisableOpps() ' Funtion to Disable all operations
        ButtonMultiply.Enabled = False
        Button1Divide.Enabled = False
        ButtonMinus.Enabled = False
        ButtonPlus.Enabled = False
        ButtonSin.Enabled = False
        ButtonCos.Enabled = False
        ButtonTan.Enabled = False
        ButtonFactorial.Enabled = False
        ButtonExponent.Enabled = False
    End Sub ' Disable all operations

    Sub EnableOpps() ' Funtion to Enable all Operations 
        ButtonNegative.Enabled = True
        ButtonMultiply.Enabled = True
        Button1Divide.Enabled = True
        ButtonMinus.Enabled = True
        ButtonPlus.Enabled = True
        ButtonSin.Enabled = True
        ButtonCos.Enabled = True
        ButtonTan.Enabled = True
        ButtonFactorial.Enabled = True
        ButtonExponent.Enabled = True
    End Sub ' Enable all operations

    Sub OppButton(opp)
        num1 = Val(Display.Text) ' Get Value from display
        Display.Text = Display.Text & " " & opp
        ButtonEquals.Tag = opp ' Notifies equalButton what kind of operation we are doing
        Display.Text = Display.Text & Newline
        DisableOpps() ' Disable all operations
        AnswerDisplayed = False ' If you press divide then we know for sure there is no answer on the screen
    End Sub ' Sub that takes care of all the operations

    'Button to make number negative
    Private Sub ButtonNegative_Click(sender As Object, e As EventArgs) Handles ButtonNegative.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen Clear screen
            Display.Text = "" ' Clear screen
            Display.Text = Display.Text & "-" ' Display  minus sign
            AnswerDisplayed = False ' Answer is not being displayedd
        Else
            Display.Text = Display.Text & "-"
        End If
    End Sub

    ' Button to Divide
    ' Button to Divide
    Private Sub Button1Divide_Click(sender As Object, e As EventArgs) Handles Button1Divide.Click
        OppButton("/")
    End Sub

    ' Button to Multiply
    Private Sub ButtonMultiply_Click(sender As Object, e As EventArgs) Handles ButtonMultiply.Click
        OppButton("*")
    End Sub

    ' Button to subtract
    Private Sub ButtonMinus_Click(sender As Object, e As EventArgs) Handles ButtonMinus.Click
        OppButton("-")
    End Sub

    ' Button to add
    Private Sub ButtonPlus_Click(sender As Object, e As EventArgs) Handles ButtonPlus.Click
        OppButton("+")

    End Sub

    ' Button to take sin
    Private Sub ButtonSin_Click(sender As Object, e As EventArgs) Handles ButtonSin.Click
        OppButton("sin")

    End Sub

    ' Button to take Cos
    Private Sub ButtonCos_Click(sender As Object, e As EventArgs) Handles ButtonCos.Click
        OppButton("cos")

    End Sub

    ' Button to take Cos
    Private Sub ButtonTan_Click(sender As Object, e As EventArgs) Handles ButtonTan.Click
        OppButton("tan")

    End Sub

    ' Button to give Factorial
    Private Sub ButtonFactorial_Click(sender As Object, e As EventArgs) Handles ButtonFactorial.Click
        OppButton("!")

    End Sub

    ' Button for Exponent
    Private Sub ButtonExponent_Click(sender As Object, e As EventArgs) Handles ButtonExponent.Click
        OppButton("^")

    End Sub

    ' Button to square
    Private Sub ButtonSquared_Click(sender As Object, e As EventArgs) Handles ButtonSquared.Click
        OppButton("²")
    End Sub

    ' Button to take square root
    Private Sub ButtonSquareroot_Click(sender As Object, e As EventArgs) Handles ButtonSquareroot.Click
        OppButton("√")
    End Sub

    ' Button to add answer into memory
    Private Sub ButtonMemory_Click(sender As Object, e As EventArgs) Handles ButtonMemory.Click
        Mem = Val(Display.Text) ' Assigns Mem the value on the display
    End Sub

    ' Button to recall number in memory
    Private Sub ButtonMemoryRecall_Click(sender As Object, e As EventArgs) Handles ButtonMemoryRecall.Click
        If AnswerDisplayed = True Then ' If there is an answer on the screen then clear it
            Display.Text = Mem ' Displays the the value in Mem onto the screen
        Else
            Display.Text = Display.Text & Mem ' Displays the the value in Mem onto the screen

        End If
    End Sub

    ' Button to clear value in memory
    Private Sub ButtonMemClear_Click(sender As Object, e As EventArgs) Handles ButtonMemClear.Click
        Mem = 0 ' Sets Mem back to 0
    End Sub


    ' Equals operator: performs the calculation the user has submitted
    Private Sub ButtonEquals_Click(sender As Object, e As EventArgs) Handles ButtonEquals.Click
        If Display.Lines.Length <= 1 Then ' If not enough number are typed then output Incorrect
            Display.Text = "Incorrect"
        Else
            num2 = Val(Display.Lines(1))
        End If

        ' Checks the tag and commputes the kind of operation picked

        If ButtonEquals.Tag = "+" Then
            answer = num1 + num2
            Display.Text = answer
            EnableOpps() 'Enable all operations
            AnswerDisplayed = True
        ElseIf ButtonEquals.Tag = "-" Then
            answer = num1 - num2
            Display.Text = answer
            EnableOpps() 'Enable all operations
            AnswerDisplayed = True
        ElseIf ButtonEquals.Tag = "*" Then
            answer = num1 * num2
            Display.Text = answer
            EnableOpps() 'Enable all operations
            AnswerDisplayed = True
        ElseIf ButtonEquals.Tag = "/" Then
            If num2 = 0 Then ' Checking if we are dividing by zero
                Display.Text = "Error!" ' Give error message
            Else
                answer = num1 / num2 ' Perform Calc
                Display.Text = answer ' Display answer
            End If

            EnableOpps() 'Enable all operations
            AnswerDisplayed = True

        ElseIf ButtonEquals.Tag = "sin" And ShiftBox.Checked = True Then
            If num1 < -1 Or num1 > 1 Then ' Check if number is in domain
                Display.Text = "Outside of Domain"
            Else
                answer = Math.Asin(num1) * 180 / Math.PI
                Display.Text = answer
            End If

            AnswerDisplayed = True
            ShiftBox.Checked = False
            EnableOpps() 'Enable all operations


        ElseIf ButtonEquals.Tag = "cos" And ShiftBox.Checked = True Then
            If num1 < -1 Or num1 > 1 Then ' Check if the num is in domain
                Display.Text = "Outside of Domian!"
            Else
                answer = Math.Acos(num1) * 180 / Math.PI
                Display.Text = answer
            End If
            AnswerDisplayed = True
            ShiftBox.Checked = False
            EnableOpps() 'Enable all operations


        ElseIf ButtonEquals.Tag = "tan" And ShiftBox.Checked = True Then
            answer = Math.Atan(num1) * 180 / Math.PI
            Display.Text = answer
            AnswerDisplayed = True
            ShiftBox.Checked = False
            EnableOpps() 'Enable all operations


        ElseIf ButtonEquals.Tag = "sin" Then
            answer = Math.Sin(num1 * Math.PI / 180)
            Display.Text = answer
            AnswerDisplayed = True
            ShiftBox.Checked = False
            EnableOpps() 'Enable all operations


        ElseIf ButtonEquals.Tag = "cos" Then

            answer = Math.Cos(num1 * Math.PI / 180)
            Display.Text = answer

            AnswerDisplayed = True
            ShiftBox.Checked = False
            EnableOpps() 'Enable all operations


        ElseIf ButtonEquals.Tag = "tan" Then
            answer = Math.Tan(num1 * Math.PI / 180)
            Display.Text = answer
            AnswerDisplayed = True
            ShiftBox.Checked = False
            EnableOpps() 'Enable all operations


        ElseIf ButtonEquals.Tag = "!" Then
            answer = 1
            If num1 = 0 Then ' 0! = 1
                answer = 1
            ElseIf num1 > 0 And num1 = Int(num1) And num1 < 28 Then ' Making sure the number isn't to big to compute
                For i = 1 To num1
                    answer *= i ' Multiply all nums until the inputed number
                Next
                Display.Text = answer
            ElseIf num1 < 0 Then ' Is N is <0 then this won't work
                Display.Text = "Int > -1" ' 
            Else
                Display.Text = "Error! Overflow!" ' Else the num is too big to compute so output an overflow message
            End If
            AnswerDisplayed = True
            EnableOpps() 'Enable all operations
        ElseIf ButtonEquals.Tag = "^" Then
            answer = num1 ^ num2
            Display.Text = answer
            AnswerDisplayed = True
            EnableOpps() 'Enable all operations
        ElseIf ButtonEquals.Tag = "²" Then
            answer = num1 ^ 2
            Display.Text = answer
            AnswerDisplayed = True
            EnableOpps() 'Enable all operations
        ElseIf ButtonEquals.Tag = "√" Then
            answer = Math.Sqrt(num1)
            Display.Text = answer
            AnswerDisplayed = True
            EnableOpps() 'Enable all operations        
        End If
    End Sub

End Class