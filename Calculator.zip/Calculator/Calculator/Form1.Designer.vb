﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Display = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button0 = New System.Windows.Forms.Button()
        Me.ButtonEquals = New System.Windows.Forms.Button()
        Me.ButtonNegative = New System.Windows.Forms.Button()
        Me.Button1Divide = New System.Windows.Forms.Button()
        Me.ButtonMultiply = New System.Windows.Forms.Button()
        Me.ButtonMinus = New System.Windows.Forms.Button()
        Me.ButtonPlus = New System.Windows.Forms.Button()
        Me.ButtonDecimal = New System.Windows.Forms.Button()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.ButtonSin = New System.Windows.Forms.Button()
        Me.ButtonCos = New System.Windows.Forms.Button()
        Me.ButtonTan = New System.Windows.Forms.Button()
        Me.ButtonFactorial = New System.Windows.Forms.Button()
        Me.ButtonExponent = New System.Windows.Forms.Button()
        Me.ButtonMemory = New System.Windows.Forms.Button()
        Me.ButtonMemoryRecall = New System.Windows.Forms.Button()
        Me.ButtonMemClear = New System.Windows.Forms.Button()
        Me.ShiftBox = New System.Windows.Forms.CheckBox()
        Me.ButtonSquared = New System.Windows.Forms.Button()
        Me.ButtonSquareroot = New System.Windows.Forms.Button()
        Me.ButtonPi = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Display
        '
        Me.Display.BackColor = System.Drawing.Color.FloralWhite
        Me.Display.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Display.Location = New System.Drawing.Point(7, 20)
        Me.Display.Multiline = True
        Me.Display.Name = "Display"
        Me.Display.Size = New System.Drawing.Size(342, 71)
        Me.Display.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.AccessibleName = "Button 1"
        Me.Button1.BackColor = System.Drawing.Color.LightGray
        Me.Button1.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(134, 283)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(67, 73)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "1"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.AccessibleName = "Button 2"
        Me.Button2.BackColor = System.Drawing.Color.LightGray
        Me.Button2.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(208, 283)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(67, 73)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "2"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.AccessibleName = "Button 3"
        Me.Button3.BackColor = System.Drawing.Color.LightGray
        Me.Button3.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(280, 282)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(67, 73)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "3"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.AccessibleName = "Button 4"
        Me.Button4.BackColor = System.Drawing.Color.LightGray
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Button4.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(134, 203)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(67, 73)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "4"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.AccessibleName = "Button 5"
        Me.Button5.BackColor = System.Drawing.Color.LightGray
        Me.Button5.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(208, 203)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(67, 73)
        Me.Button5.TabIndex = 5
        Me.Button5.Text = "5"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.AccessibleName = "Button 6"
        Me.Button6.BackColor = System.Drawing.Color.LightGray
        Me.Button6.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(280, 202)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(67, 73)
        Me.Button6.TabIndex = 6
        Me.Button6.Text = "6"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.AccessibleName = "Button 7"
        Me.Button7.BackColor = System.Drawing.Color.LightGray
        Me.Button7.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(134, 124)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(67, 73)
        Me.Button7.TabIndex = 7
        Me.Button7.Text = "7"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.AccessibleName = "Button 8"
        Me.Button8.BackColor = System.Drawing.Color.LightGray
        Me.Button8.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(208, 124)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(67, 73)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "8"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.AccessibleName = "Button 9"
        Me.Button9.BackColor = System.Drawing.Color.LightGray
        Me.Button9.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(280, 123)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(67, 73)
        Me.Button9.TabIndex = 9
        Me.Button9.Text = "9"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button0
        '
        Me.Button0.AccessibleName = "Button 0"
        Me.Button0.BackColor = System.Drawing.Color.LightGray
        Me.Button0.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button0.Location = New System.Drawing.Point(208, 361)
        Me.Button0.Name = "Button0"
        Me.Button0.Size = New System.Drawing.Size(141, 73)
        Me.Button0.TabIndex = 10
        Me.Button0.Text = "0"
        Me.Button0.UseVisualStyleBackColor = False
        '
        'ButtonEquals
        '
        Me.ButtonEquals.AccessibleName = "Button equalSign"
        Me.ButtonEquals.BackColor = System.Drawing.Color.White
        Me.ButtonEquals.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonEquals.Location = New System.Drawing.Point(207, 439)
        Me.ButtonEquals.Name = "ButtonEquals"
        Me.ButtonEquals.Size = New System.Drawing.Size(143, 73)
        Me.ButtonEquals.TabIndex = 11
        Me.ButtonEquals.Text = "="
        Me.ButtonEquals.UseVisualStyleBackColor = False
        '
        'ButtonNegative
        '
        Me.ButtonNegative.AccessibleName = "Button ToggleSign"
        Me.ButtonNegative.BackColor = System.Drawing.Color.White
        Me.ButtonNegative.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonNegative.Location = New System.Drawing.Point(71, 417)
        Me.ButtonNegative.Name = "ButtonNegative"
        Me.ButtonNegative.Size = New System.Drawing.Size(54, 48)
        Me.ButtonNegative.TabIndex = 12
        Me.ButtonNegative.Text = "(-)"
        Me.ButtonNegative.UseVisualStyleBackColor = False
        '
        'Button1Divide
        '
        Me.Button1Divide.AccessibleName = "Button 9"
        Me.Button1Divide.BackColor = System.Drawing.Color.White
        Me.Button1Divide.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1Divide.Location = New System.Drawing.Point(72, 121)
        Me.Button1Divide.Name = "Button1Divide"
        Me.Button1Divide.Size = New System.Drawing.Size(54, 50)
        Me.Button1Divide.TabIndex = 13
        Me.Button1Divide.Text = "÷"
        Me.Button1Divide.UseVisualStyleBackColor = False
        '
        'ButtonMultiply
        '
        Me.ButtonMultiply.AccessibleName = "Button 9"
        Me.ButtonMultiply.BackColor = System.Drawing.Color.White
        Me.ButtonMultiply.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMultiply.Location = New System.Drawing.Point(72, 172)
        Me.ButtonMultiply.Name = "ButtonMultiply"
        Me.ButtonMultiply.Size = New System.Drawing.Size(54, 49)
        Me.ButtonMultiply.TabIndex = 14
        Me.ButtonMultiply.Text = "x"
        Me.ButtonMultiply.UseVisualStyleBackColor = False
        '
        'ButtonMinus
        '
        Me.ButtonMinus.AccessibleName = "Button 9"
        Me.ButtonMinus.BackColor = System.Drawing.Color.White
        Me.ButtonMinus.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMinus.Location = New System.Drawing.Point(72, 219)
        Me.ButtonMinus.Name = "ButtonMinus"
        Me.ButtonMinus.Size = New System.Drawing.Size(54, 51)
        Me.ButtonMinus.TabIndex = 15
        Me.ButtonMinus.Text = "-"
        Me.ButtonMinus.UseVisualStyleBackColor = False
        '
        'ButtonPlus
        '
        Me.ButtonPlus.AccessibleName = "Button +"
        Me.ButtonPlus.BackColor = System.Drawing.Color.White
        Me.ButtonPlus.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonPlus.Location = New System.Drawing.Point(72, 269)
        Me.ButtonPlus.Name = "ButtonPlus"
        Me.ButtonPlus.Size = New System.Drawing.Size(54, 50)
        Me.ButtonPlus.TabIndex = 16
        Me.ButtonPlus.Text = "+"
        Me.ButtonPlus.UseVisualStyleBackColor = False
        '
        'ButtonDecimal
        '
        Me.ButtonDecimal.AccessibleName = "Button ToggleSign"
        Me.ButtonDecimal.BackColor = System.Drawing.Color.White
        Me.ButtonDecimal.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonDecimal.Location = New System.Drawing.Point(133, 362)
        Me.ButtonDecimal.Name = "ButtonDecimal"
        Me.ButtonDecimal.Size = New System.Drawing.Size(68, 73)
        Me.ButtonDecimal.TabIndex = 17
        Me.ButtonDecimal.Text = "."
        Me.ButtonDecimal.UseVisualStyleBackColor = False
        '
        'ButtonClear
        '
        Me.ButtonClear.AccessibleName = "Button ToggleSign"
        Me.ButtonClear.BackColor = System.Drawing.Color.White
        Me.ButtonClear.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonClear.Location = New System.Drawing.Point(134, 439)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(67, 73)
        Me.ButtonClear.TabIndex = 18
        Me.ButtonClear.Text = "CE"
        Me.ButtonClear.UseVisualStyleBackColor = False
        '
        'ButtonSin
        '
        Me.ButtonSin.AccessibleName = "Button 9"
        Me.ButtonSin.BackColor = System.Drawing.Color.White
        Me.ButtonSin.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSin.Location = New System.Drawing.Point(12, 271)
        Me.ButtonSin.Name = "ButtonSin"
        Me.ButtonSin.Size = New System.Drawing.Size(54, 50)
        Me.ButtonSin.TabIndex = 19
        Me.ButtonSin.Text = "Sin"
        Me.ButtonSin.UseVisualStyleBackColor = False
        '
        'ButtonCos
        '
        Me.ButtonCos.AccessibleName = "Button 9"
        Me.ButtonCos.BackColor = System.Drawing.Color.White
        Me.ButtonCos.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCos.Location = New System.Drawing.Point(12, 322)
        Me.ButtonCos.Name = "ButtonCos"
        Me.ButtonCos.Size = New System.Drawing.Size(54, 46)
        Me.ButtonCos.TabIndex = 20
        Me.ButtonCos.Text = "Cos"
        Me.ButtonCos.UseVisualStyleBackColor = False
        '
        'ButtonTan
        '
        Me.ButtonTan.AccessibleName = "Button 9"
        Me.ButtonTan.BackColor = System.Drawing.Color.White
        Me.ButtonTan.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonTan.Location = New System.Drawing.Point(12, 368)
        Me.ButtonTan.Name = "ButtonTan"
        Me.ButtonTan.Size = New System.Drawing.Size(54, 49)
        Me.ButtonTan.TabIndex = 21
        Me.ButtonTan.Text = "Tan"
        Me.ButtonTan.UseVisualStyleBackColor = False
        '
        'ButtonFactorial
        '
        Me.ButtonFactorial.AccessibleName = "Button 9"
        Me.ButtonFactorial.BackColor = System.Drawing.Color.White
        Me.ButtonFactorial.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonFactorial.Location = New System.Drawing.Point(12, 416)
        Me.ButtonFactorial.Name = "ButtonFactorial"
        Me.ButtonFactorial.Size = New System.Drawing.Size(54, 49)
        Me.ButtonFactorial.TabIndex = 23
        Me.ButtonFactorial.Text = "!"
        Me.ButtonFactorial.UseVisualStyleBackColor = False
        '
        'ButtonExponent
        '
        Me.ButtonExponent.AccessibleName = "Button +"
        Me.ButtonExponent.BackColor = System.Drawing.Color.White
        Me.ButtonExponent.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonExponent.Location = New System.Drawing.Point(72, 464)
        Me.ButtonExponent.Name = "ButtonExponent"
        Me.ButtonExponent.Size = New System.Drawing.Size(54, 49)
        Me.ButtonExponent.TabIndex = 24
        Me.ButtonExponent.Text = "^"
        Me.ButtonExponent.UseVisualStyleBackColor = False
        '
        'ButtonMemory
        '
        Me.ButtonMemory.AccessibleName = "Button 9"
        Me.ButtonMemory.BackColor = System.Drawing.Color.White
        Me.ButtonMemory.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMemory.Location = New System.Drawing.Point(12, 172)
        Me.ButtonMemory.Name = "ButtonMemory"
        Me.ButtonMemory.Size = New System.Drawing.Size(54, 48)
        Me.ButtonMemory.TabIndex = 26
        Me.ButtonMemory.Text = "M"
        Me.ButtonMemory.UseVisualStyleBackColor = False
        '
        'ButtonMemoryRecall
        '
        Me.ButtonMemoryRecall.AccessibleName = "Button 9"
        Me.ButtonMemoryRecall.BackColor = System.Drawing.Color.White
        Me.ButtonMemoryRecall.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMemoryRecall.Location = New System.Drawing.Point(12, 122)
        Me.ButtonMemoryRecall.Name = "ButtonMemoryRecall"
        Me.ButtonMemoryRecall.Size = New System.Drawing.Size(54, 50)
        Me.ButtonMemoryRecall.TabIndex = 27
        Me.ButtonMemoryRecall.Text = "MRC"
        Me.ButtonMemoryRecall.UseVisualStyleBackColor = False
        '
        'ButtonMemClear
        '
        Me.ButtonMemClear.AccessibleName = "Button 9"
        Me.ButtonMemClear.BackColor = System.Drawing.Color.White
        Me.ButtonMemClear.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonMemClear.Location = New System.Drawing.Point(12, 221)
        Me.ButtonMemClear.Name = "ButtonMemClear"
        Me.ButtonMemClear.Size = New System.Drawing.Size(54, 50)
        Me.ButtonMemClear.TabIndex = 28
        Me.ButtonMemClear.Text = "MC"
        Me.ButtonMemClear.UseVisualStyleBackColor = False
        '
        'ShiftBox
        '
        Me.ShiftBox.AutoSize = True
        Me.ShiftBox.Location = New System.Drawing.Point(15, 97)
        Me.ShiftBox.Name = "ShiftBox"
        Me.ShiftBox.Size = New System.Drawing.Size(44, 17)
        Me.ShiftBox.TabIndex = 29
        Me.ShiftBox.Text = "2nd"
        Me.ShiftBox.UseVisualStyleBackColor = True
        '
        'ButtonSquared
        '
        Me.ButtonSquared.AccessibleName = "Button +"
        Me.ButtonSquared.BackColor = System.Drawing.Color.White
        Me.ButtonSquared.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSquared.Location = New System.Drawing.Point(70, 367)
        Me.ButtonSquared.Name = "ButtonSquared"
        Me.ButtonSquared.Size = New System.Drawing.Size(55, 51)
        Me.ButtonSquared.TabIndex = 30
        Me.ButtonSquared.Text = "x²"
        Me.ButtonSquared.UseVisualStyleBackColor = False
        '
        'ButtonSquareroot
        '
        Me.ButtonSquareroot.AccessibleName = "Button +"
        Me.ButtonSquareroot.BackColor = System.Drawing.Color.White
        Me.ButtonSquareroot.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSquareroot.Location = New System.Drawing.Point(71, 319)
        Me.ButtonSquareroot.Name = "ButtonSquareroot"
        Me.ButtonSquareroot.Size = New System.Drawing.Size(54, 49)
        Me.ButtonSquareroot.TabIndex = 31
        Me.ButtonSquareroot.Text = "√"
        Me.ButtonSquareroot.UseVisualStyleBackColor = False
        '
        'ButtonPi
        '
        Me.ButtonPi.AccessibleName = "Button 9"
        Me.ButtonPi.BackColor = System.Drawing.Color.White
        Me.ButtonPi.Font = New System.Drawing.Font("Calibri Light", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonPi.Location = New System.Drawing.Point(12, 464)
        Me.ButtonPi.Name = "ButtonPi"
        Me.ButtonPi.Size = New System.Drawing.Size(54, 49)
        Me.ButtonPi.TabIndex = 32
        Me.ButtonPi.Text = "π"
        Me.ButtonPi.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(355, 518)
        Me.Controls.Add(Me.ButtonPi)
        Me.Controls.Add(Me.ButtonSquareroot)
        Me.Controls.Add(Me.ButtonSquared)
        Me.Controls.Add(Me.ShiftBox)
        Me.Controls.Add(Me.ButtonMemClear)
        Me.Controls.Add(Me.ButtonMemoryRecall)
        Me.Controls.Add(Me.ButtonMemory)
        Me.Controls.Add(Me.ButtonExponent)
        Me.Controls.Add(Me.ButtonFactorial)
        Me.Controls.Add(Me.ButtonTan)
        Me.Controls.Add(Me.ButtonCos)
        Me.Controls.Add(Me.ButtonSin)
        Me.Controls.Add(Me.ButtonClear)
        Me.Controls.Add(Me.ButtonDecimal)
        Me.Controls.Add(Me.ButtonPlus)
        Me.Controls.Add(Me.ButtonMinus)
        Me.Controls.Add(Me.ButtonMultiply)
        Me.Controls.Add(Me.Button1Divide)
        Me.Controls.Add(Me.ButtonNegative)
        Me.Controls.Add(Me.ButtonEquals)
        Me.Controls.Add(Me.Button0)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Display)
        Me.Name = "Form1"
        Me.Text = "Calculator ++"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Display As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button0 As Button
    Friend WithEvents ButtonEquals As Button
    Friend WithEvents ButtonNegative As Button
    Friend WithEvents Button1Divide As Button
    Friend WithEvents ButtonMultiply As Button
    Friend WithEvents ButtonMinus As Button
    Friend WithEvents ButtonPlus As Button
    Friend WithEvents ButtonDecimal As Button
    Friend WithEvents ButtonClear As Button
    Friend WithEvents ButtonSin As Button
    Friend WithEvents ButtonCos As Button
    Friend WithEvents ButtonTan As Button
    Friend WithEvents ButtonFactorial As Button
    Friend WithEvents ButtonExponent As Button
    Friend WithEvents ButtonMemory As Button
    Friend WithEvents ButtonMemoryRecall As Button
    Friend WithEvents ButtonMemClear As Button
    Friend WithEvents ShiftBox As CheckBox
    Friend WithEvents ButtonSquared As Button
    Friend WithEvents ButtonSquareroot As Button
    Friend WithEvents ButtonPi As Button
End Class
